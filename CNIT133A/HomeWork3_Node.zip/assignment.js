var StudentAge = 20;
var LimitedAge = 20;
if (StudentAge > LimitedAge) {
    console.log("Hello, dear student, you are " + StudentAge + " years old and you are allowed to drink!");
}
else {
    console.log("Hello, dear student, you are " + LimitedAge + " years old and you are NOT allowed to drink!");
}
